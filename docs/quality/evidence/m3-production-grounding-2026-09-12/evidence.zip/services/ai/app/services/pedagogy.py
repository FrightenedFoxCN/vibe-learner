from __future__ import annotations

import re

from app.services.study_grounding import citation_tokens

from app.models.domain import (
    Citation,
    DialogueTurnRecord,
    DocumentDebugRecord,
    ExerciseResult,
    LearningPlanRecord,
    PersonaProfile,
    PersonaSlotTraceRecord,
    StudyChatResult,
    MemoryTraceHitRecord,
    StudySessionRecord,
    SubmissionGradeResult,
    persona_sorted_slots,
)
from app.services.provider_capabilities import TeachingModelCapability
from app.services.performance import PerformanceMapper
from app.services.study_memory import build_memory_context, retrieve_memory_hits
from app.models.study_question import project_study_question_proposal
from app.models.study_chat_operation import StudyChatMessageKind


class PedagogyOrchestrator:
    def __init__(
        self, *, model_provider: TeachingModelCapability, performance_mapper: PerformanceMapper
    ) -> None:
        self.model_provider = model_provider
        self.performance_mapper = performance_mapper

    def generate_chat_reply(
        self,
        *,
        session_id: str,
        persona: PersonaProfile,
        message: str,
        message_kind: StudyChatMessageKind = "learner",
        study_unit_id: str,
        study_unit_title: str = "",
        theme_hint: str = "",
        active_plan: LearningPlanRecord | None = None,
        session_system_prompt: str = "",
        debug_report: DocumentDebugRecord | None = None,
        document_path: str | None = None,
        previous_turns: list[DialogueTurnRecord] | None = None,
        memory_sessions: list[StudySessionRecord] | None = None,
        active_plan_context: str = "",
        attachment_context: str = "",
        learner_multimodal_parts: list[dict[str, object]] | None = None,
        session_state_context: str = "",
        active_scene_summary: str = "",
        active_scene_context: str = "",
        session_tool_runtime=None,
        plan_tool_runtime=None,
        scene_tool_runtime=None,
    ) -> StudyChatResult:
        turns = previous_turns or []
        section_context = _build_section_context(
            debug_report=debug_report,
            study_unit_id=study_unit_id,
            study_unit_title=study_unit_title,
            theme_hint=theme_hint,
            active_plan=active_plan,
        )
        conversation_history = _build_conversation_history(turns)
        memory_hits = retrieve_memory_hits(
            sessions=memory_sessions or [],
            current_session_id=session_id,
            active_study_unit_id=study_unit_id,
            query=message,
            active_scene_summary=active_scene_summary,
            embed_texts=self.model_provider.embed_texts,
        )
        memory_context = build_memory_context(memory_hits)
        memory_hit_payloads = [item.model_dump(mode="json") for item in memory_hits]
        raw_reply = self.model_provider.generate_chat(
            persona=persona,
            section_id=study_unit_id,
            message=message,
            message_kind=message_kind,
            session_prompt=session_system_prompt,
            section_context=section_context,
            memory_context=memory_context,
            attachment_context=attachment_context,
            learner_multimodal_parts=learner_multimodal_parts,
            scene_context=active_scene_context,
            active_plan_context=active_plan_context,
            session_state_context=session_state_context,
            session_tool_runtime=session_tool_runtime,
            plan_tool_runtime=plan_tool_runtime,
            scene_tool_runtime=scene_tool_runtime,
            memory_trace_hits=memory_hit_payloads,
            conversation_history=conversation_history,
            debug_report=debug_report,
            document_path=document_path,
        )
        citations = _build_grounded_citations(
            debug_report=debug_report,
            study_unit_id=study_unit_id,
            study_unit_title=study_unit_title,
            message=message,
        )
        turn_index = len(turns)
        events = self.performance_mapper.map_text_to_events(
            persona=persona,
            text=raw_reply.text,
            mood=raw_reply.mood,
            action=raw_reply.action,
            line_segment_id=f"{session_id}:chat:{turn_index}",
            speech_style=raw_reply.speech_style,
            delivery_cue=raw_reply.delivery_cue,
            commentary=raw_reply.state_commentary,
        )
        scene_hint = _build_scene_hint(study_unit_id=study_unit_id, citations=citations)
        for event in events:
            event.scene_hint = scene_hint
        tool_events = self.performance_mapper.map_tool_calls_to_events(
            persona=persona,
            tool_calls=raw_reply.tool_calls or [],
            line_segment_id=f"{session_id}:chat:{turn_index}",
        )
        slot_trace = _build_persona_slot_trace(persona=persona, message=message)
        memory_trace = _normalize_memory_trace(raw_reply.memory_trace, memory_hits)
        return StudyChatResult(
            reply=raw_reply.text,
            citations=citations,
            character_events=[*events, *tool_events],
            rich_blocks=raw_reply.rich_blocks or [],
            interactive_question=(
                project_study_question_proposal(raw_reply.interactive_question)
                if raw_reply.interactive_question is not None
                else None
            ),
            persona_slot_trace=slot_trace,
            memory_trace=memory_trace,
            tool_calls=raw_reply.tool_calls or [],
            scene_profile=raw_reply.scene_profile,
        )

    def generate_exercise(
        self, *, persona: PersonaProfile, section_id: str, topic: str
    ) -> ExerciseResult:
        raw_reply = self.model_provider.generate_exercise(
            persona=persona, section_id=section_id, topic=topic
        )
        events = self.performance_mapper.map_text_to_events(
            persona=persona,
            text=raw_reply.text,
            mood=raw_reply.mood,
            action=raw_reply.action,
            line_segment_id=f"{section_id}:exercise:0",
            speech_style=raw_reply.speech_style,
            delivery_cue=raw_reply.delivery_cue,
            commentary=raw_reply.state_commentary,
        )
        return ExerciseResult(
            exercise_id=f"exercise-{section_id}",
            section_id=section_id,
            prompt=raw_reply.text,
            exercise_type="short_answer",
            difficulty="medium",
            guidance="先回忆教材定义，再写出一个对应示例。",
            character_events=events,
        )

    def grade_submission(
        self, *, persona: PersonaProfile, exercise_id: str, answer: str
    ) -> SubmissionGradeResult:
        raw_reply = self.model_provider.grade_submission(
            persona=persona, exercise_id=exercise_id, answer=answer
        )
        events = self.performance_mapper.map_text_to_events(
            persona=persona,
            text=raw_reply.text,
            mood=raw_reply.mood,
            action=raw_reply.action,
            line_segment_id=f"{exercise_id}:grade:0",
            speech_style=raw_reply.speech_style,
            delivery_cue=raw_reply.delivery_cue,
            commentary=raw_reply.state_commentary,
        )
        score = 88 if len(answer.strip()) > 24 else 61
        diagnosis = (
            ["概念覆盖较全", "示例支撑充足"]
            if score > 80
            else ["定义不够完整", "缺少教材中的例子"]
        )
        recommendation = "回看本章定义段落后，再补写一个和教材一致的例子。"
        return SubmissionGradeResult(
            score=score,
            diagnosis=diagnosis,
            recommendation=recommendation,
            character_events=events,
        )


def _build_conversation_history(turns: list[DialogueTurnRecord]) -> list[dict[str, str]]:
    history: list[dict[str, str]] = []
    for turn in turns[-6:]:
        learner_text = turn.learner_message.strip()
        assistant_text = turn.assistant_reply.strip()
        if learner_text:
            history.append({"role": "user", "content": learner_text})
        if assistant_text:
            history.append({"role": "assistant", "content": assistant_text})
    return history


def _build_scene_hint(*, study_unit_id: str, citations: list[Citation]) -> str:
    if not citations:
        return f"study_session:{study_unit_id}:overview"
    start = min(citation.page_start for citation in citations)
    end = max(citation.page_end for citation in citations)
    return f"study_session:{study_unit_id}:p{start}-{end}"


def _build_section_context(
    *,
    debug_report: DocumentDebugRecord | None,
    study_unit_id: str,
    study_unit_title: str = "",
    theme_hint: str = "",
    active_plan: LearningPlanRecord | None = None,
) -> str:
    if debug_report is None:
        return _build_goal_only_section_context(
            study_unit_id=study_unit_id,
            study_unit_title=study_unit_title,
            theme_hint=theme_hint,
            active_plan=active_plan,
        )

    resolved_study_unit_title = study_unit_title or study_unit_id
    page_start = 0
    page_end = 0
    related_ids = {study_unit_id}

    study_unit = next((unit for unit in debug_report.study_units if unit.id == study_unit_id), None)
    if study_unit is not None:
        resolved_study_unit_title = study_unit.title
        page_start = study_unit.page_start
        page_end = study_unit.page_end
        related_ids.update(study_unit.source_section_ids)

    parsed_section = next((section for section in debug_report.sections if section.id == study_unit_id), None)
    if parsed_section is not None and resolved_study_unit_title == study_unit_id:
        resolved_study_unit_title = parsed_section.title
        page_start = parsed_section.page_start
        page_end = parsed_section.page_end

    chunks = [
        chunk
        for chunk in debug_report.chunks
        if chunk.section_id in related_ids
    ]
    if not chunks and page_start > 0 and page_end > 0:
        chunks = [
            chunk
            for chunk in debug_report.chunks
            if chunk.page_end >= page_start and chunk.page_start <= page_end
        ]
    excerpts = [
        _truncate_for_prompt(chunk.content or chunk.text_preview, limit=220)
        for chunk in chunks[:2]
        if (chunk.content or chunk.text_preview).strip()
    ]
    excerpt_text = "\n".join(f"- {line}" for line in excerpts)
    if excerpt_text:
        parts = [
            f"学习单元：{resolved_study_unit_title} ({study_unit_id})",
            f"页码：{page_start}-{page_end}",
        ]
        if theme_hint.strip():
            parts.append(f"当前主题：{theme_hint.strip()}")
        if active_plan is not None and active_plan.objective.strip():
            parts.append(f"学习目标：{active_plan.objective.strip()}")
        parts.append(f"教材摘录：\n{excerpt_text}")
        return "\n".join(parts)
    parts = [f"学习单元：{resolved_study_unit_title} ({study_unit_id})", f"页码：{page_start}-{page_end}"]
    if theme_hint.strip():
        parts.append(f"当前主题：{theme_hint.strip()}")
    if active_plan is not None and active_plan.objective.strip():
        parts.append(f"学习目标：{active_plan.objective.strip()}")
    return "\n".join(parts)


def _build_goal_only_section_context(
    *,
    study_unit_id: str,
    study_unit_title: str,
    theme_hint: str,
    active_plan: LearningPlanRecord | None,
) -> str:
    resolved_title = study_unit_title.strip() or study_unit_id
    parts = [f"学习单元：{resolved_title} ({study_unit_id})"]
    if active_plan is not None:
        parts.append(f"计划模式：{active_plan.creation_mode}")
        if active_plan.objective.strip():
            parts.append(f"学习目标：{active_plan.objective.strip()}")
        matching_unit = next(
            (
                unit
                for unit in active_plan.study_units
                if unit.id == study_unit_id or study_unit_id in unit.source_section_ids
            ),
            None,
        )
        if theme_hint.strip():
            parts.append(f"当前主题：{theme_hint.strip()}")
        if matching_unit is not None and matching_unit.summary.strip():
            parts.append(f"阶段摘要：{matching_unit.summary.strip()}")
        study_unit_progress = next(
            (item for item in active_plan.study_unit_progress if item.unit_id == study_unit_id),
            None,
        )
        if study_unit_progress is not None and study_unit_progress.objective_fragment.strip():
            parts.append(f"学习单元目标：{study_unit_progress.objective_fragment.strip()}")
    elif theme_hint.strip():
        parts.append(f"当前主题：{theme_hint.strip()}")
    return "\n".join(parts)


def _build_grounded_citations(
    *,
    debug_report: DocumentDebugRecord | None,
    study_unit_id: str,
    study_unit_title: str,
    message: str,
) -> list[Citation]:
    if debug_report is None:
        return []

    title = study_unit_id
    page_start = 1
    page_end = 1
    related_ids = {study_unit_id}

    unit = next((item for item in debug_report.study_units if item.id == study_unit_id), None)
    if unit is not None:
        title = unit.title
        page_start = unit.page_start
        page_end = unit.page_end
        related_ids.update(unit.source_section_ids)

    section = next((item for item in debug_report.sections if item.id == study_unit_id), None)
    if section is not None and title == study_unit_id:
        title = section.title
        page_start = section.page_start
        page_end = section.page_end

    tokens = citation_tokens(message)
    candidate_chunks = [
        chunk
        for chunk in debug_report.chunks
        if chunk.section_id in related_ids
    ]
    if not candidate_chunks:
        candidate_chunks = [
            chunk
            for chunk in debug_report.chunks
            if chunk.page_end >= page_start and chunk.page_start <= page_end
        ]

    scored_chunks: list[tuple[int, int, int, str]] = []
    for chunk in candidate_chunks:
        chunk_tokens = citation_tokens(f"{chunk.text_preview}\n{chunk.content}")
        score = len(tokens & chunk_tokens)
        if score > 0:
            scored_chunks.append((score, chunk.page_start, chunk.page_end, chunk.section_id))

    scored_chunks.sort(key=lambda item: (item[0], -(item[2] - item[1])), reverse=True)

    citations: list[Citation] = []
    seen_ranges: set[tuple[int, int, str]] = set()
    for _, start, end, raw_section_id in scored_chunks[:3]:
        key = (start, end, raw_section_id)
        if key in seen_ranges:
            continue
        seen_ranges.add(key)
        citations.append(
            Citation(
                section_id=raw_section_id,
                title=title,
                page_start=start,
                page_end=end,
            )
        )

    return citations


def _tokenize(text: str) -> list[str]:
    return [token for token in re.findall(r"[a-zA-Z0-9\u4e00-\u9fff]{2,}", text.lower())]


def _truncate_for_prompt(text: str, *, limit: int) -> str:
    compact = " ".join(text.strip().split())
    if len(compact) <= limit:
        return compact
    return compact[: limit - 3] + "..."


def _build_persona_slot_trace(*, persona: PersonaProfile, message: str) -> list[PersonaSlotTraceRecord]:
    tokens = set(_tokenize(message))
    scored: list[tuple[int, int, PersonaSlotTraceRecord]] = []
    for index, slot in enumerate(persona_sorted_slots(persona.slots)):
        content = slot.content.strip()
        if not content:
            continue
        content_lower = content.lower()
        score = sum(1 for token in tokens if token in content_lower)
        if score == 0 and slot.kind not in ("teaching_method", "thinking_style", "worldview"):
            continue
        reason = "命中提问关键词" if score > 0 else "作为人格基础策略默认参与"
        scored.append(
            (
                score,
                index,
                PersonaSlotTraceRecord(
                    kind=slot.kind,
                    label=slot.label,
                    content_excerpt=_truncate_for_prompt(content, limit=80),
                    reason=reason,
                ),
            )
        )
    scored.sort(key=lambda item: (item[0], -item[1]), reverse=True)
    return [item[2] for item in scored[:4]]


def _normalize_memory_trace(
    raw_hits: list[dict[str, object]] | None,
    fallback: list[MemoryTraceHitRecord],
) -> list[MemoryTraceHitRecord]:
    if not raw_hits:
        return fallback
    result: list[MemoryTraceHitRecord] = []
    for item in raw_hits:
        try:
            result.append(
                MemoryTraceHitRecord(
                    session_id=str(item.get("session_id") or ""),
                    study_unit_id=str(item.get("study_unit_id") or item.get("section_id") or ""),
                    scene_title=str(item.get("scene_title") or "未设置场景"),
                    score=float(item.get("score") or 0),
                    snippet=str(item.get("snippet") or ""),
                    created_at=str(item.get("created_at") or ""),
                    source=str(item.get("source") or "tool_call"),
                )
            )
        except Exception:
            continue
    return result or fallback
